<template>
<div>
    register
</div>
</template>
<style scoped>
</style>
<script>
 export default {
  data(){
     return{}
  },
  created(){},
  methods:{}
 }
</script>