<template>
   <div>
       
   </div>
</template>
   
<style scoped>
   
</style>
   
<script>
   
   export default {
       data() {
           return {
           }
       },
       created() {
           
       },
       methods: {
           
       }
   }
</script>